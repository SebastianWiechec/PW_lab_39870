﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class S1 : MonoBehaviour
{
    GameObject[] wskazane;

    // Start is called before the first frame update
    void Start()
    {
        wskazane = GameObject.FindGameObjectsWithTag("kula");
        foreach (GameObject znaleziony in wskazane)
        {
            Destroy(znaleziony);
        }
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
